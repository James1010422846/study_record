#sudo python3.6 -m pip install jupyter -i https://pypi.doubanio.com/simple

cd ../jupyterexample
jupyter notebook --ip=0.0.0.0 --allow-root
