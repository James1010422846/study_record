# 配置/脚本区

- ubuntu16.sh  ubuntu 16 一键安装脚本
- startjupyter.sh   开启jupyter notebook
- run_backend.sh 开启mongod后台,WEBKIT前后台
- update_data.py 更新数据脚本
