最新版qa-base基础上增加了Kite Engine组件； 

Kite Engine组件是jupyterlab-kite插件的基础支持模块，实现对kite服务器python等通用编程语言扩展库函数索引，本地库函数索引，本地编程输入词频学习进化；

Kite Engine安装过程需要人工交互，增加了kitesetup.exp自动应答脚本，就可以正常build镜像；

DaoCloud现在不开放注册组织了，镜像用不了私人仓库，有需要我可以传群里；
