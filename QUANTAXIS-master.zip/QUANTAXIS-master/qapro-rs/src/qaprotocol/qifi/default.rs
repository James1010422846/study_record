pub fn default_f64() -> f64 {
    0f64
}

pub fn default_i64() -> i64 {
    0i64
}

pub fn default_bool() -> bool {
    false
}

pub fn default_i128() -> i128 {
    0i128
}

pub fn default_i32() -> i32 {
    0i32
}

pub fn default_string() -> String {
    "".to_string()
}
