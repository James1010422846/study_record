# Scipy jupyter notebook 
Login and tokenization disabled


# Instructions to Run
docker build -t jupyter_scipy .
docker run -p 8888:8888 jupyter_scipy