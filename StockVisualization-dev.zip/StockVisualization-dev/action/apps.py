from django.apps import AppConfig


class ActionConfig(AppConfig):
    name = 'action'
